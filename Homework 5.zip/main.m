clc
clear
%Call function to load data
[fname]=Function1
%load data
data=load(fname);
result=0;
choice=menu('Please choose a statistical operation','mean','standard deviation','variance','min','max')
switch choice
    case 1
        result=mean(data);
    case 2
        result=std(data);
    case 3
        result=var(data);
    case 4
        result=min(data);
    case 5
        result=max(data);
end
 %Call function to display the choice
 Function2(result,choice)
 %Call function to do plotting
 Function3(data)