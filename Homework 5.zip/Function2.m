function Function2(result,choice)
switch choice
    case 1
        disp(['The mean of this function is ',num2str(result)])
    case 2
        disp(['The standard deviation of this function is ',num2str(result)])
    case 3
        disp(['The variance of this function is ',num2str(result)])
    case 4
        disp(['The minimum of this function is ',num2str(result)])
    case 5
        disp(['The maximum of this function is ',num2str(result)])
end